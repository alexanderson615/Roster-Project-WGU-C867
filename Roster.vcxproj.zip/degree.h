#ifndef DEGREE_H
#define DEGREE_H

enum DegreeProgram { NETWORKING, SECURITY, SOFTWARE};

#endif
